# From CSV file to API

This is a way to build a GET API from a CSV file. <br />
<br />
For the moment, only the GET methods are suppored.
<br />
<br />
Be sure to download the required tools for the library to work: <br />
<br />
* requests>=2.25.1,
* Flask>=1.1.2